class_name Moneda
extends Area2D

# Velocidad de caída en píxeles por segundo
@export var velocidad: float = 300.0

# Referencia al nodo de la animación
@onready var sprite_animado: AnimatedSprite2D = $AnimatedSprite2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	# Iniciamos la animación
	sprite_animado.play("default")

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	# Mover la moneda hacia abajo
	position.y += velocidad * delta

signal la_moneda_ha_salido

func _on_visible_on_screen_enabler_2d_screen_exited() -> void:
	print("la moneda ha salido de la pantalla") # Replace with function body.
	la_moneda_ha_salido.emit(self)
