extends CharacterBody2D

const velocidad: int = 400

func _physics_process(delta: float) -> void:
	# 1. Obtener la dirección de entrada del jugador (-1, 0, o 1 en cada eje)
	var direccion: Vector2 = Input.get_vector("ui_left", "ui_right", "ui_up", "ui_down")
	
	# 2. Asignar la velocidad física (move_and_slide aplicará delta automáticamente)
	velocity = direccion * velocidad

	# 3. Orientar el sprite según el sentido horizontal
	if direccion.x < 0:
		$Sprite2D.flip_h = false
	elif direccion.x > 0:
		$Sprite2D.flip_h = true

	# 4. Mover el autobús respetando colisiones físicas
	move_and_slide()

	# 5. Restringir la posición dentro de los bordes permitidos
	var tamano_pantalla: Vector2 = get_viewport_rect().size
	position.x = clamp(position.x, 0, tamano_pantalla.x)
	position.y = clamp(position.y, 0, tamano_pantalla.y)
