extends Node2D

const MONEDA_SCENE = preload("res://scenes/moneda.tscn")

# Referencia al label de los puntos
@onready var label_puntos: Label = $LabelPuntos

# Puntos conseguidos
var puntos: int = 0

func _ready() -> void:
	# Creamos la primera moneda al iniciar
	crear_nueva_moneda()

func crear_nueva_moneda() -> void:
	# Creamos una nueva moneda
	var moneda_actual = MONEDA_SCENE.instantiate() as Moneda
	
	# Evento de cuando la moneda es tocada
	# TODO
	
	# Posicionamos la moneda en un lugar aleatorio dentro de la pantalla
	reposicionar_moneda(moneda_actual)
	
	# La añadimos a la escena
	add_child(moneda_actual)
	
	
func reposicionar_moneda(moneda: Moneda) -> void:
	var tamano_pantalla = get_viewport_rect().size
	var margen: float = 32.0 # Margen para que no aparezca pegada al borde
	
	var pos_x = randf_range(margen, tamano_pantalla.x - margen)
	var pos_y = randf_range(margen, tamano_pantalla.y - margen)
	
	moneda.position = Vector2(pos_x, pos_y)
