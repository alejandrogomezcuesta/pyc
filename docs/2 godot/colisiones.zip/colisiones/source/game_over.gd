extends Control

func _ready() -> void:
	# Conectamos la señal 'pressed' del botón con la función local
	$VBoxContainer/Button.pressed.connect(_on_button_pressed)

func _on_button_pressed() -> void:
	# Cambiamos a la escena principal del juego
	get_tree().change_scene_to_file("res://scenes/presentacion.tscn")
