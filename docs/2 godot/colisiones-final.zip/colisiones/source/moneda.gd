class_name Moneda
extends Area2D

# Referencia al nodo de la animación
@onready var sprite_animado: AnimatedSprite2D = $AnimatedSprite2D

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
# Iniciamos la animación (cambia "default" por el nombre que le diste a tu animación)
	sprite_animado.play("default")
	
signal al_tocar_moneda

func _on_body_entered(body: Node2D) -> void:
	al_tocar_moneda.emit(self)
	print("Algo ha tocado la moneda") # Replace with function body.
