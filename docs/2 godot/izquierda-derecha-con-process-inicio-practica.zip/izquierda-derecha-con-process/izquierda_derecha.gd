extends Node2D

@onready var sprite_2d: Sprite2D = $Sprite2D
const velocidad: int = 200

func _process(delta: float) -> void:
	# Comprobar si la acción 'ui_left' está activa
	if Input.is_action_pressed("ui_left"):
		sprite_2d.position.x -= velocidad * delta
	
	# Comprobar si la acción 'ui_right' está activa
	if Input.is_action_pressed("ui_right"):
		sprite_2d.position.x += velocidad * delta
