extends Node2D

@onready var sprite_2d: Sprite2D = $Sprite2D

func _on_izquierda_button_pressed() -> void:
	sprite_2d.position.x = sprite_2d.position.x - 10
	print("La posición del objeto es: " + str(sprite_2d.position.x))
